import java.util.Scanner;
/**
 * 
 * @author zaknilsen
 *
 */
public class TenziDriver {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		Die die = new Die();
		TenziGame game = new TenziGame();
		boolean gameOver;


		for (int i = 0; i < 10; i++) {
			die.roll();
			System.out.println(i + ":" + die);
		}
		
		
		gameOver = game.isOver();
		while (gameOver == false) {
			int dieReroll;   
			game.getTurns();
			System.out.println("Which to roll: " + keyboard);
			dieReroll = keyboard.nextInt();
			
			if (game.isOver() == true) {
				System.out.println("Game over." + "  Time is " + game.getTimeElapsed());
				
				System.out.println("Play again? (Y/N)");
				if (keyboard.next() == "Y") {
				    gameOver = false;
				} else {
				    gameOver = true;
				}
				return;
			}
		}
	}
			
	/**
	 * 	
	 */
	public int[] splitToInts(String dieReroll) {
		int[] userInts = {};
		dieReroll.split(",");
		return userInts;
	}
}
