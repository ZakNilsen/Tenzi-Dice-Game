import java.util.Random;

/**
 * 
 * @author zaknilsen
 *
 */
public class Die {
	
	// instance variables 
	/** */
	private int faceValue;
	
	
	// constructors methods 
	public Die() {
		faceValue = 1;
	}
	
	//methods
	/**
	 * 	
	 * @return
	 */
	public int getFaceValue() {
		return faceValue;
	}
	/**
	 * 
	 */
	public void roll() {
		Random generator = new Random();
		faceValue = generator.nextInt(6)+1;
	}
		
	/**
	 * 
	 * @return
	 */
	@Override
	public String toString() {
		if (faceValue == 1) {
			return "*";
		} else if (faceValue == 2) {
			return "* *";
		} else if (faceValue == 3) {
				return "* * *";
		} else if (faceValue == 4) {
			return "* * * *";
		} else if (faceValue == 5) {
			return "* * * * *";
		} else {
			return "* * * * * *";
		}
	}
}
			
			
		
	
	
	
	
	
	


