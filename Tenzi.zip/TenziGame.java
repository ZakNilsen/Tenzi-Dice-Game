import java.util.ArrayList;
/**
 * 
 * @author zaknilsen
 *
 */
public class TenziGame {
	//initializers
	/** */
	private int turns;
	/** */
	private long startTime;
	/** */
	private long endTime;
	/** */
	private ArrayList<Die> theDice;
	//constructors
	public TenziGame() {
	theDice = new ArrayList<Die>();	
	}
	//methods
	/**
	 * 
	 * @return
	 */
	public boolean isOver() {
	    for (int i = 0; i < theDice.size()-1; i++) {
            if (theDice.get(i) != theDice.get(i+1)) {
                return false;
            }
        }
        return true;
	}
	/**
	 * 
	 * @param rolls
	 */
	public void roll(int[] rolls) {

	}
	/**
	 * 
	 * @return
	 */
	public long getTimeElapsed() {
		startTime = System.currentTimeMillis();
		if (isOver() == true) {
			endTime = System.currentTimeMillis() - startTime;
		}
		return endTime * 1000;
		
	}
	/**
	 * 
	 * @return
	 */
	public int getTurns() {
		this.turns = 0;
		turns = turns + 1;
		return turns;
		
	}
	/**
	 * 
	 * @return 
	 */
	@Override
	public String toString() {
		//what will this toString method be used for
		return null;
		
	}
}
