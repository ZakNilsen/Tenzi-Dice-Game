import java.util.ArrayList;
/**
 * 
 * @author zaknilsen
 *
 */
public class Leaderboard {
	//initializers
	/** */
	private ArrayList<Long> bestTimes;
	//constructors
	public Leaderboard() {
		return;
	}
	//methods
		/**
		 * 
		 * @param longInt
		 */
		public void update(long time) {
			for (int i = 0; i < bestTimes.size(); i++) {
				if (bestTimes.get(i) > time) {
					bestTimes.set(i, time);
				}
			}
				
		}
		/**
		 * 
		 * @return 
		 */
		@Override
		public String toString() {
			String leaderboard  = "--Current Leaderboard (in seconds)--\n";
			for (int i = 0;  i < bestTimes.size(); i++) {
			    leaderboard = leaderboard + bestTimes.get(i).toString()+"\n";
			}
			return "";
			
		}
}
